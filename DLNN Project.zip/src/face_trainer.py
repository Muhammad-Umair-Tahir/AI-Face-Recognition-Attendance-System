# Suppress macOS warnings
import warnings
warnings.filterwarnings('ignore', category=UserWarning)

import cv2
import numpy as np
from PIL import Image
import os
import logging
import json
from deepface import DeepFace
from settings import PATHS  # Contains keys: 'image_dir', 'embeddings_file', 'names_file'

# Configure logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants (should match the recognizer configuration)
EMBEDDING_MODEL_NAME = "Facenet"      # or any other model supported by DeepFace
DETECTOR_BACKEND = "mtcnn"         # retinaface is often more accurate than opencv

def validate_training_data(path: str) -> bool:
    """Validate training data structure and content."""
    logger.info(f"Validating training data at: {path}")
    if not os.path.exists(path):
        logger.error(f"Training directory not found: {path}")
        return False

    valid_extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.webp')
    valid_students = 0

    for student_name in os.listdir(path):
        student_dir = os.path.join(path, student_name)
        if not os.path.isdir(student_dir):
            continue

        valid_images = 0
        for fname in os.listdir(student_dir):
            if fname.lower().endswith(valid_extensions):
                valid_images += 1

        if valid_images > 0:
            valid_students += 1
            logger.info(f"Found {valid_images} images for '{student_name}'")
        else:
            logger.warning(f"No valid images found for '{student_name}' in {student_dir}")

    if valid_students == 0:
        logger.error("No valid training data found. Requirements:")
        logger.error("  - Subdirectories named with student names")
        logger.error("  - At least 1 image per subdirectory (png/jpg/jpeg/bmp/webp)")
        return False

    return True

def get_images_and_labels(path: str):
    """
    Process training images to extract embeddings and labels.

    Returns:
        embeddings_list: list of face embeddings (as lists or numpy arrays)
        ids: list of corresponding integer IDs for each embedding
        name_to_id_mapping: dictionary mapping string IDs to student names
    """
    embeddings_list = []
    ids = []
    name_to_id_mapping = {}
    current_id = 0

    if not validate_training_data(path):
        raise ValueError("Invalid training data. Please check the directory structure and image files.")

    try:
        for student_name in sorted(os.listdir(path)):
            student_dir = os.path.join(path, student_name)
            if not os.path.isdir(student_dir):
                continue

            current_id += 1
            # Map the new student ID (as string) to the student name.
            name_to_id_mapping[str(current_id)] = student_name
            processed_images = 0
            failed_images = 0

            for fname in os.listdir(student_dir):
                if not fname.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.webp')):
                    continue

                image_path = os.path.join(student_dir, fname)
                try:
                    img = cv2.imread(image_path)
                    if img is None:
                        logger.warning(f"Failed to read image: {image_path}")
                        failed_images += 1
                        continue

                    # Extract face embeddings from the image.
                    # Note: DeepFace.represent can accept a numpy array as img_path.
                    embedding_objs = DeepFace.represent(
                        img_path=img,
                        model_name=EMBEDDING_MODEL_NAME,
                        detector_backend=DETECTOR_BACKEND,
                        enforce_detection=False,  # Strict face detection for training
                        align=True,
                        normalization='base'
                    )

                    if embedding_objs:
                        # If multiple faces are detected, process each one.
                        for face in embedding_objs:
                            embeddings_list.append(face['embedding'])
                            ids.append(current_id)
                        processed_images += 1
                    else:
                        logger.warning(f"No faces detected in {image_path}")
                        failed_images += 1

                except Exception as e:
                    logger.warning(f"Error processing {image_path}: {str(e)}")
                    failed_images += 1
                    continue

            logger.info(f"Processed '{student_name}': {processed_images} success, {failed_images} failed")

        if not embeddings_list:
            raise ValueError(
                "Failed to extract any embeddings. Check: "
                "Image quality (clear frontal faces), "
                "Minimum image size (recommended 160x160px), "
                "and proper face visibility in images."
            )

        return embeddings_list, ids, name_to_id_mapping

    except Exception as e:
        logger.error(f"Fatal error in processing training data: {str(e)}")
        raise

def save_embeddings(embeddings_list, ids, name_to_id_mapping, filename):
    """Save embeddings and metadata to a compressed .npz file."""
    try:
        np.savez_compressed(
            filename,
            embeddings=np.array(embeddings_list),
            ids=np.array(ids),
            id_to_name=json.dumps(name_to_id_mapping)  # Save mapping as a JSON string
        )
        logger.info(f"Embeddings saved to: {filename}")
    except Exception as e:
        logger.error(f"Error saving embeddings: {e}")

def save_name_mapping_json(name_to_id_mapping: dict, filename: str) -> None:
    """Save the name-to-ID mapping to a JSON file."""
    try:
        with open(filename, 'w', encoding='utf-8') as fs:
            json.dump(name_to_id_mapping, fs, indent=4, ensure_ascii=False)
        logger.info(f"Saved name-to-ID mapping to JSON file: {filename}")
    except Exception as e:
        logger.error(f"Error saving name-to-ID mapping JSON: {e}")

if __name__ == "__main__":
    try:
        logger.info("Starting training process...")

        training_dir = PATHS['image_dir']
        if not os.path.exists(training_dir):
            raise FileNotFoundError(f"Training directory not found: {training_dir}")

        # Extract embeddings and labels from the training data.
        embeddings, ids, mapping = get_images_and_labels(training_dir)

        if len(embeddings) == 0:
            raise RuntimeError(
                "Failed to extract any embeddings. Check: "
                "Image quality (clear frontal faces), "
                "Minimum image size (recommended 160x160px), "
                "and face visibility in images."
            )

        logger.info(f"Successfully extracted {len(embeddings)} embeddings for {len(mapping)} students")

        # Save the extracted embeddings and name mapping.
        save_embeddings(embeddings, ids, mapping, PATHS['embeddings_file'])
        save_name_mapping_json(mapping, PATHS['names_file'])

    except Exception as e:
        logger.error(f"Training failed: {str(e)}")
        logger.info("Troubleshooting steps:")
        logger.info("1. Verify the training directory structure and file formats.")
        logger.info("2. Ensure images contain clear, frontal faces with proper lighting.")
        logger.info("3. Adjust the detector_backend if needed (e.g., try 'opencv' instead of 'retinaface').")
        logger.info("4. Test with sample images to isolate the issue.")

