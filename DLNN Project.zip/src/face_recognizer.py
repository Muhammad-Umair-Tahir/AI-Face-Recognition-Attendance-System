# Suppress macOS warnings
import warnings
warnings.filterwarnings('ignore', category=UserWarning)

import cv2
import numpy as np
import json
import os
import logging
import datetime
import pandas as pd
import time
from deepface import DeepFace
from scipy.spatial.distance import cosine
from sklearn.metrics.pairwise import cosine_similarity
from settings.settings import CAMERA, FACE_DETECTION, PATHS

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration (Must match trainer.py)
EMBEDDING_MODEL_NAME = "Facenet"
DETECTOR_BACKEND = "mtcnn"
RECOGNITION_THRESHOLD = 0.6
ATTENDANCE_COOLDOWN = 300

class FaceRecognizer:
    def __init__(self):
        self.embeddings = None
        self.ids = None
        self.id_to_name = {}
        self.last_detected = {}
        self.face_cascade = None
        self.cam = None

    def initialize(self):
        """Initialize all components"""
        self._load_embeddings()
        self._load_name_mapping()
        self._initialize_face_detection()
        self._initialize_camera()

    def _load_embeddings(self):
        """Load embeddings with validation"""
        try:
            data = np.load(PATHS['embeddings_file'], allow_pickle=True)
            self.embeddings = data['embeddings']
            self.ids = data['ids']
            
            if 'id_to_name' in data:
                self.id_to_name = json.loads(data['id_to_name'].item())
            else:
                self._load_name_mapping()

            if self.embeddings.shape[0] == 0:
                raise ValueError("No embeddings loaded")
                
            logger.info(f"Loaded {len(self.ids)} embeddings")

        except Exception as e:
            logger.error(f"Embedding load error: {e}")
            raise

    def _load_name_mapping(self):
        """Load name mappings from JSON file"""
        try:
            if os.path.exists(PATHS['names_file']):
                with open(PATHS['names_file'], 'r') as f:
                    # Do not invert the mapping: the file already has id-to-name mapping.
                    self.id_to_name = json.load(f)
                logger.info(f"Loaded {len(self.id_to_name)} name mappings")
        except Exception as e:
            logger.error(f"Name mapping error: {e}")

    def _initialize_face_detection(self):
        """Initialize face detection components"""
        self.face_cascade = cv2.CascadeClassifier(PATHS['cascade_file'])
        if self.face_cascade.empty():
            logger.warning("Haar cascade not found")

    def _initialize_camera(self):
        """Initialize video capture device"""
        try:
            self.cam = cv2.VideoCapture(CAMERA['index'])
            self.cam.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA['width'])
            self.cam.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA['height'])
            if not self.cam.isOpened():
                raise RuntimeError("Camera failed to initialize")
            logger.info("Camera initialized successfully")
        except Exception as e:
            logger.error(f"Camera error: {e}")
            raise

    def _process_frame(self, frame):
        """Process a single frame for face recognition"""
        try:
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            faces = self._detect_faces(rgb_frame)
        
            for face in faces:
                # If the face is a NumPy array, convert it to a list.
                if isinstance(face, np.ndarray):
                    face = face.tolist()
    
                # Normalize the format based on type and length.
                if isinstance(face, (list, tuple)):
                    if len(face) == 5:
                        x, y, w, h, _ = face
                    elif len(face) == 4:
                        x, y, w, h = face
                    else:
                        logger.warning(f"Unexpected face tuple length: {len(face)} - {face}")
                        continue
                elif isinstance(face, dict):
                    # Adjust key names as needed based on your detector's output.
                    x = face.get("x") or face.get("left")
                    y = face.get("y") or face.get("top")
                    w = face.get("w") or face.get("width")
                    h = face.get("h") or face.get("height")
                    if None in (x, y, w, h):
                        logger.warning(f"Incomplete face coordinates in dict: {face}")
                        continue
                else:
                    logger.warning(f"Unexpected face format: {face}")
                    continue

                # Proceed with processing using x, y, w, h
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                face_region = rgb_frame[y:y+h, x:x+w]

                embedding = self._get_face_embedding(face_region)
                if embedding is not None:
                    self._recognize_face(frame, embedding, (x, y, h))
        
            return frame
        except Exception as e:
            logger.error(f"Frame processing error: {e}")
            return frame

    def _detect_faces(self, frame):
        """Face detection using combined methods"""
        faces = []
        try:
            # Try DeepFace detector first
            deep_faces = DeepFace.extract_faces(
                frame,
                detector_backend=DETECTOR_BACKEND,
                enforce_detection=False
            )
            faces = [f['facial_area'] for f in deep_faces if f['confidence'] > 0.9]
        except Exception as e:
            logger.warning(f"DeepFace detection failed: {e}")

        # Fallback to Haar cascades if needed
        if not faces and not self.face_cascade.empty():
            gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=FACE_DETECTION['scale_factor'],
                minNeighbors=FACE_DETECTION['min_neighbors'],
                minSize=FACE_DETECTION['min_size']
            )

        return faces

    def _get_face_embedding(self, face_region):
        """Extract face embedding with error handling"""
        try:
            result = DeepFace.represent(
                img_path=face_region,
                model_name=EMBEDDING_MODEL_NAME,
                detector_backend="mtcnn",
                enforce_detection=False,
                align=True
            )
            
            if result:
                embedding = np.array(result[0]['embedding'], dtype=np.float32)
                return embedding
            return None
        except Exception as e:
            logger.warning(f"Embedding extraction failed: {e}")
            return None

    def _recognize_face(self, frame, embedding, position):
        """Recognize face and update display"""
        x, y, h = position
        
        # Vectorized similarity calculation
        similarities = cosine_similarity([embedding], self.embeddings)[0]
        best_match_idx = np.argmax(similarities)
        max_similarity = similarities[best_match_idx]
        
        if max_similarity > (1 - RECOGNITION_THRESHOLD):
            person_id = str(self.ids[best_match_idx])
            name = self.id_to_name.get(person_id, "Unknown")
            confidence = f"{max_similarity*100:.1f}%"
            
            # Update display
            cv2.putText(frame, name, (x+5, y-5), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            cv2.putText(frame, confidence, (x+5, y+h-5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 1)
            
            # Record attendance
            self._record_attendance(person_id, name)

    def _record_attendance(self, person_id, name):
        """Handle attendance recording with cooldown"""
        current_time = time.time()
        last_recorded = self.last_detected.get(person_id, 0)
        
        if current_time - last_recorded > ATTENDANCE_COOLDOWN:
            try:
                record_attendance(person_id, name)
                self.last_detected[person_id] = current_time
                logger.info(f"Attendance recorded for {name} ({person_id})")
            except Exception as e:
                logger.error(f"Attendance error: {e}")

    def run(self):
        """Main recognition loop"""
        try:
            while True:
                ret, frame = self.cam.read()
                if not ret:
                    logger.warning("Frame capture failed")
                    continue
                
                processed_frame = self._process_frame(frame)
                cv2.imshow('Face Recognition', processed_frame)
                
                if cv2.waitKey(1) & 0xFF == 27:
                    break

        except Exception as e:
            logger.error(f"Runtime error: {e}")
        finally:
            self.cam.release()
            cv2.destroyAllWindows()
            logger.info("System shutdown complete")

def record_attendance(person_id, name):
    """Attendance recording function"""
    attendance_file = 'attendance_dl.xlsx'
    now = datetime.datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")

    new_entry = pd.DataFrame([{
        'ID': person_id,
        'Name': name,
        'Date': date_str,
        'Time': time_str,
        'Status': 'Present'
    }])

    try:
        if os.path.exists(attendance_file):
            existing = pd.read_excel(attendance_file)
            combined = pd.concat([existing, new_entry], ignore_index=True)
            combined.drop_duplicates(subset=['ID', 'Date'], keep='last', inplace=True)
            combined.to_excel(attendance_file, index=False)
        else:
            new_entry.to_excel(attendance_file, index=False)
    except Exception as e:
        logger.error(f"Attendance save failed: {e}")

if __name__ == "__main__":
    try:
        logger.info("Initializing face recognition system...")
        recognizer = FaceRecognizer()
        recognizer.initialize()
        recognizer.run()
    except Exception as e:
        logger.error(f"Initialization failed: {e}")