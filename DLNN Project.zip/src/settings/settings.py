"""
Configuration settings for the face recognition system
"""
import os

# Camera settings
CAMERA = {
    'index': 0,  # Default camera (0 is usually built-in webcam)
    'width': 640,
    'height': 480
}

# Face detection settings
FACE_DETECTION = {
    'scale_factor': 1.3,
    'min_neighbors': 5,
    'min_size': (30, 30)
}

# Training settings. Number of images needed to train the model.
TRAINING = {
    'samples_needed': 2
}

# File paths
PATHS = {
    'image_dir': '/home/umair/UNI/DL Project/Deep Learning/Dataset',  # Path to your image directory
    'names_file': 'n/student_names.json', # Path for student names JSON
    'trainer_file': 'trainer.yml', # (Not used anymore in this DL version for training)
    'cascade_file': '/home/umair/UNI/DL Project/Deep Learning/haarcascade_frontalface_default.xml',
    'embeddings_file': 'n/face_embeddings.npz' # Add this line for embeddings file
}